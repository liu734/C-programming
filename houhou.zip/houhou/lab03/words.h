#define SIZE 140

int readMsg(char*);
int getWord(char*, int, int*, int*);
void checkWord(char*, int, char**, int);
void unCapitalize(char*);
