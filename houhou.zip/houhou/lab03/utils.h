int isAlpha(char);
int strLen(char*);
int strNCmp(char*, char*, int);
void spaceOut(char*, int);
